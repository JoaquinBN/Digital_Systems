package view;

import controller.TowerController;
import view.dialogs.ErrorDialog;
import view.dialogs.SaveRecordingDialog;
import view.dialogs.SerialDialog;

import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.*;

public class TowerView extends JFrame {
    public static final String APP_NAME = "LS Control Tower";

    public static final int FRAME_WIDTH = 1280;
    public static final int FRAME_HEIGHT = 720;
    public static final int ICON_SIZE = 48;
    public static final int HEADER_SIZE = 24;
    public static final int FONT_SIZE = 18;

    public static final Color BACKGROUND_COLOR = new Color(255, 255, 255);
    public static final Color XYLOPHONE_COLOR = new Color(204, 204, 204);
    public static final Color BUTTON_COLOR = new Color(204, 204, 204);
    public static final Color FONT_COLOR = new Color(34, 34, 34);
    public static final Color PLACEHOLDER_COLOR = new Color(204, 204, 204);
    public static final Color STATUS_COLOR = new Color(109, 182, 101);

    public static final String MESSAGE_STATUS_CONNECTED = "Connected";
    public static final String MESSAGE_STATUS_RECORDING = "Connected (Recording)";

    public static final String AC_MUTE = "AC_MUTE";
    public static final String AC_SERIAL = "AC_SERIAL";

    private static final String IC_VOLUME = "res/icon/volume.png";
    private static final String IC_VOLUME_MUTE = "res/icon/volume-mute.png";
    private static final String IC_SERIAL = "res/icon/serial.png";


    private static final String TW_NAME = "Current control tower: ";
    private static final String REC_NAME = "Name of the recording";
    private static final String REC_TOWER = "Control tower";
    private static final String REC_TIMESTAMP = "Timestamp";
    private static final String REC_ID = "ID";
    private static final String[] REC_COL = {REC_NAME, REC_TOWER, REC_TIMESTAMP, REC_ID};
    private static final int ID_INDEX = 3;

    private JPanel mainView;
    private JScrollPane jScrollPane;
    private JButton volumeButton;
    private JButton serialButton;
    private JLabel statusLabel;
    private JLabel towerLabel;

    private JTable recordingsTable;
    private DefaultTableModel recordingsModel;

    public TowerView() {
        configureView();
        configureFrame();
    }

    /* -------------------------------------- FRAME CONFIGURATION -------------------------------------- */

    private void configureFrame() {
        this.pack();
        this.setTitle(APP_NAME);
        this.setSize(FRAME_WIDTH, FRAME_HEIGHT);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setContentPane(mainView);
    }

    /* -------------------------------------- PANEL CONFIGURATION -------------------------------------- */

    private void configureView() {
        mainView = new JPanel();
        mainView.setLayout(new BorderLayout());

        configureNorth();
        configureCenter();
        configureSouth();

        /* Padding */
        mainView.add(createPadding(BACKGROUND_COLOR, 50, 0), BorderLayout.WEST);
        mainView.add(createPadding(BACKGROUND_COLOR, 50, 0), BorderLayout.EAST);
    }

    private void configureNorth() {
        JPanel northPanel = new JPanel(new BorderLayout());

        /* Center */
        JLabel titleLabel = createLabel(APP_NAME, HEADER_SIZE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        statusLabel = createLabel(MESSAGE_STATUS_CONNECTED, FONT_SIZE);
        statusLabel.setForeground(STATUS_COLOR);
        statusLabel.setVisible(false);
        statusLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setBackground(BACKGROUND_COLOR);
        headerPanel.add(titleLabel);
        headerPanel.add(statusLabel);
        northPanel.add(headerPanel, BorderLayout.CENTER);

        /* East */
        volumeButton = createIconButton(IC_VOLUME, AC_MUTE);

        JPanel configPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
        configPanel.setBackground(BACKGROUND_COLOR);
        configPanel.add(volumeButton);
        configPanel.add(createPadding(BACKGROUND_COLOR, 10, 0));
        northPanel.add(configPanel, BorderLayout.EAST);

        /* West */
        serialButton = createIconButton(IC_SERIAL, AC_SERIAL);

        JPanel serialPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
        serialPanel.setBackground(BACKGROUND_COLOR);
        serialPanel.add(createPadding(BACKGROUND_COLOR, 10, 0));
        serialPanel.add(serialButton);
        serialPanel.add(createPadding(BACKGROUND_COLOR, 30, 0));
        northPanel.add(serialPanel, BorderLayout.WEST);

        /* Padding */
        northPanel.add(createPadding(BACKGROUND_COLOR, 0, 20), BorderLayout.NORTH);
        northPanel.add(createPadding(BACKGROUND_COLOR, 0, 50), BorderLayout.SOUTH);

        mainView.add(northPanel, BorderLayout.NORTH);
    }

    private void configureCenter() {
        JPanel centerPanel = new JPanel(new BorderLayout());

        /* Center */
        JPanel xylophonePanel = new JPanel(new FlowLayout());
        xylophonePanel.setBackground(XYLOPHONE_COLOR);

        /* Create the table and its model for the recordings */
        createTableAndModel();
        configureTable();
        jScrollPane = new JScrollPane(recordingsTable, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        centerPanel.add(jScrollPane, BorderLayout.CENTER);

        /* Padding */
        centerPanel.add(createPadding(XYLOPHONE_COLOR, 20, 0), BorderLayout.WEST);
        centerPanel.add(createPadding(XYLOPHONE_COLOR, 20, 0), BorderLayout.EAST);
        centerPanel.add(createPadding(XYLOPHONE_COLOR, 0, 20), BorderLayout.NORTH);
        centerPanel.add(createPadding(XYLOPHONE_COLOR, 0, 20), BorderLayout.SOUTH);

        mainView.add(centerPanel, BorderLayout.CENTER);
    }

    private void configureSouth() {
        JPanel southPanel = new JPanel(new BorderLayout());
        southPanel.setBackground(BACKGROUND_COLOR);

        /* West */
        towerLabel = createLabel(TW_NAME, FONT_SIZE);

        JPanel songPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 10));
        songPanel.setBackground(BACKGROUND_COLOR);
        songPanel.add(createPadding(BACKGROUND_COLOR, 10, 0));
        songPanel.add(towerLabel);
        southPanel.add(songPanel, BorderLayout.WEST);

        /* Padding */
        southPanel.add(createPadding(BACKGROUND_COLOR, 0, 50), BorderLayout.NORTH);
        southPanel.add(createPadding(BACKGROUND_COLOR, 0, 20), BorderLayout.SOUTH);

        mainView.add(southPanel, BorderLayout.SOUTH);
    }

    /* -------------------------------------- COMPONENTS FACTORY -------------------------------------- */

    public static JPanel createPadding(Color color, int width, int height) {
        JPanel border = new JPanel();
        border.setBackground(color);
        border.add(Box.createRigidArea(new Dimension(width, height)));
        return border;
    }

    public static JLabel createLabel(String text, int textSize) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("SansSerif", Font.BOLD, textSize));
        label.setForeground(FONT_COLOR);
        return label;
    }

    public static JButton createButton(String text, String actionCommand) {
        JButton button = new JButton(text);
        button.setBackground(BUTTON_COLOR);
        button.setForeground(FONT_COLOR);
        button.setFont(new Font("SansSerif", Font.BOLD, FONT_SIZE));
        button.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        button.setFocusPainted(false);
        button.setActionCommand(actionCommand);
        return button;
    }

    public static JLabel createIconLabel(String imgPath) {
        JLabel iconLabel = new JLabel(createImage(imgPath));
        iconLabel.setPreferredSize(new Dimension(ICON_SIZE, ICON_SIZE));
        iconLabel.setMaximumSize(iconLabel.getPreferredSize());
        iconLabel.setBackground(BACKGROUND_COLOR);
        iconLabel.setBorder(BorderFactory.createEmptyBorder());
        return iconLabel;
    }

    public static JButton createIconButton(String imgPath, String actionCommand) {
        JButton iconButton = new JButton(createImage(imgPath));
        iconButton.setPreferredSize(new Dimension(ICON_SIZE, ICON_SIZE));
        iconButton.setMaximumSize(iconButton.getPreferredSize());
        iconButton.setBackground(BACKGROUND_COLOR);
        iconButton.setBorder(BorderFactory.createEmptyBorder());
        iconButton.setFocusPainted(false);
        iconButton.setActionCommand(actionCommand);
        return iconButton;
    }

    private static ImageIcon createImage(String imagePath) {
        ImageIcon resource = new ImageIcon(imagePath);
        Image image = resource.getImage().getScaledInstance(ICON_SIZE, ICON_SIZE, Image.SCALE_SMOOTH);
        return new ImageIcon(image);
    }

    public void createTableAndModel() {
        recordingsModel = new DefaultTableModel(REC_COL, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        recordingsTable = new JTable();
        recordingsTable.setModel(recordingsModel);
    }

    public void configureTable() {
        recordingsTable.setRowHeight(30);
        recordingsTable.setShowGrid(false);

        JTableHeader tableHeader = recordingsTable.getTableHeader();
        tableHeader.setReorderingAllowed(false);
        tableHeader.setResizingAllowed(false);
        ((DefaultTableCellRenderer) tableHeader.getDefaultRenderer()).setHorizontalAlignment(JLabel.CENTER);

        // Center all cells with strings
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        for (int i = 0; i < REC_COL.length; i++) {
            recordingsTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
    }

    /* -------------------------------------- CONTROLLER -------------------------------------- */

    public void registerController(TowerController controller) {
        volumeButton.addActionListener(controller);
        serialButton.addActionListener(controller);
        recordingsTable.addMouseListener(controller);
    }

    public JTable getjTable() {
        return recordingsTable;
    }

    public String getSelectedID() {
        int modelRow = recordingsTable.convertRowIndexToModel(recordingsTable.getSelectedRow());
        return (String) recordingsModel.getValueAt(modelRow, ID_INDEX);
    }

    /* -------------------------------------- DIALOGS -------------------------------------- */

    public void displayError(String errorTitle, String errorMessage) {
        new ErrorDialog(this, errorTitle, errorMessage).openDialog();
    }

    public boolean configureSerial() {
        SerialDialog serialDialog = new SerialDialog(this, "Serial Configuration");
        return serialDialog.openDialog();
    }

    public String saveRecording() {
        SaveRecordingDialog saveRecordingDialog = new SaveRecordingDialog(this, "Save Recording");

        return (saveRecordingDialog.openDialog()) ? saveRecordingDialog.getRecordingName() : null;
    }

    /* -------------------------------------- VIEW UPDATE -------------------------------------- */

    public void setTowerName(String name) {
        towerLabel.setText(TW_NAME + name);
    }

    public String getTowerName() {
        return towerLabel.getText().substring(TW_NAME.length());
    }

    public void swapVolumeIcon(boolean isMute) {
        volumeButton.setIcon((!isMute) ? createImage(IC_VOLUME) : createImage(IC_VOLUME_MUTE));
    }

    public void updateStatus(boolean status) {
        serialButton.setEnabled(!status);
        statusLabel.setVisible(status);
    }

    public void setRecording(boolean isRecording) {
        String statusMessage = (isRecording) ? MESSAGE_STATUS_RECORDING : MESSAGE_STATUS_CONNECTED;
        statusLabel.setText(statusMessage);
    }

    public void addRecording(String name, String tower, String timestamp, String songID) {
        recordingsModel.addRow(new Object[]{name, tower, timestamp, songID});
        recordingsTable.repaint();
    }

    public void loadModelData(List<List<String>> recordings) {
        clearModelData();
        for (List<String> rec : recordings) {
            addRecording(
                    rec.get(0),
                    rec.get(1),
                    rec.get(2),
                    rec.get(3)
            );
        }
        recordingsTable.repaint();
    }

    public void clearModelData() {
        while (recordingsModel.getRowCount() > 0) {
            recordingsModel.removeRow(0);
        }
    }
}
