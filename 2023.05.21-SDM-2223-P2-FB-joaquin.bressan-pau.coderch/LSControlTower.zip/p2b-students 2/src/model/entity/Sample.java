package model.entity;

public class Sample {
    private byte sampleValue;

    public Sample() {
    }

    // Byte received over the serial link
    public Sample(byte sampleValue) {
        this.sampleValue = sampleValue;
    }

    // Get the sample value (byte) of the object
    public byte getSampleValue() {
        return sampleValue;
    }
}
