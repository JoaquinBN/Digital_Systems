package model.entity;

import java.util.ArrayList;
import java.util.List;

public class Recording {
    public static final int TIMESTAMP_LEN = 5;
    public static final int MAX_SAMPLES = 32768;
    public static float SAMPLING_RATE = 4000;

    private String name;
    private String tower;
    private String timestamp;
    private String id;
    private List<Sample> samples;

    public Recording() {}

    public Recording(String name, String tower, String timestamp, String id, List<Sample> samples) {
        this.name = name;
        this.tower = tower;
        this.timestamp = timestamp;
        this.id = id;
        this.samples = new ArrayList<>(samples);
    }

    public String getName() {
        return name;
    }

    public String getTower() {
        return tower;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public String getId() {
        return id;
    }
    public int getSampleLength() {
        return samples.size();
    }
    public byte getSample(int i) {
        return samples.get(i).getSampleValue();
    }
}
