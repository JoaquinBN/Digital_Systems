package model;

import controller.TowerController;
import model.dao.recordingDAO;
import model.dao.json.JSONRecordingDAO;
import model.entity.*;

import javax.sound.sampled.*;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class TowerManager {
    private TowerController controller;
    private final recordingDAO recordingDAO;
    private FloatControl floatControl;
    private List<Recording> recordings;
    private Clip clip;
    private boolean muted;
    private boolean recordBlocked;

    public TowerManager() {
        recordingDAO = new JSONRecordingDAO();
        muted = false;
        recordBlocked = false;
    }

    /* -------------------------------------- CONTROLLER -------------------------------------- */

    public void registerController(TowerController controller) {
        this.controller = controller;
    }

    /* -------------------------------------- RECORDING --------------------------------------- */

    public void receiveRequest() {
        new Thread(() ->
        {
            System.out.println("RECEIVE REQUEST");
            Serial serial = Serial.getInstance();
            //serial.sendCharacter('P');


            while (true) {
                //System.out.println("RECEIVING");
                if (serial.isConnected()) {
                    System.out.println("CONNECTED");
                    char sample = serial.receiveSample();
                    //System.out.println("RECEIVED " + sample);
                    /* Receive a new song */
                    if (sample == 'D') {
                        System.out.println("SENT D");
                        recordBlocked = true;
                        controller.startRecording();
                        receiveTrack();
                        controller.updateRecordings();
                        controller.endRecording();
                    /* Receive a request to play a song */
                    } else if (sample == 'P' && !recordBlocked) {
                        System.out.println("SENT P");
                        recordBlocked = true;
                        receiveRequestToPlay();
                    /* Set the tower name to whatever the user sets */
                    } else if (sample == 'T' && !recordBlocked) {
                        System.out.println("SENT T");
                        receiveTower();
                    }
                } else {
                    System.out.println("NOT CONNECTED");
                }
            }
        }).start();
    }

    public List<List<String>> getAllRecordings() {
        recordings = recordingDAO.getAllRecordings();
        List<List<String>> recordingsStr = new ArrayList<>();

        for (Recording recording : recordings) {
            List<String> recordingStr = new ArrayList<>();
            recordingStr.add(recording.getName());
            recordingStr.add(recording.getTower());
            recordingStr.add(recording.getTimestamp());
            recordingStr.add(recording.getId());
            recordingsStr.add(recordingStr);
        }

        return recordingsStr;
    }

    public String createAudio(String selectedID) {
        String path = null;

        for (Recording recording : recordings) {
            if (recording.getId().equals(selectedID)) {
                path = JSONRecordingDAO.PATH_AUDIO + recording.getName() + JSONRecordingDAO.EXT_AUDIO;
                File file = new File(path);
                if (!file.exists()) {
                    byte[] buffer = new byte[recording.getSampleLength()];
                    for (int i = 0; i < recording.getSampleLength(); i++) {
                        buffer[i] = recording.getSample(i);
                    }
                    AudioFormat format = new AudioFormat(Recording.SAMPLING_RATE, 8, 1, false, true);
                    ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
                    AudioInputStream audioInputStream = new AudioInputStream(bais, format, recording.getSampleLength());
                    try {
                        AudioSystem.write(audioInputStream, AudioFileFormat.Type.WAVE, file);
                        audioInputStream.close();
                    } catch (IOException ioException) {
                        controller.displayError("Audio processing failed", "The audio file could not be " +
                                "created from the samples received. Check your code.");
                    }
                }
                break;
            }
        }

        return path;
    }

    public boolean mute() {
        muted = !muted;
        floatControl.setValue((floatControl.getValue() != floatControl.getMinimum()
                ? floatControl.getMinimum() : floatControl.getMaximum()));
        return (floatControl.getValue() == floatControl.getMinimum());
    }

    public synchronized void playAudio(String path, boolean inform_ended) {
        File file = new File(path);
        //System.out.println("PLAYING " + path);

        try {
            try {
                clip.stop();
                clip.close();
            } catch (Exception ignored) {
            }
            AudioInputStream stream = AudioSystem.getAudioInputStream(file);
            AudioFormat format = stream.getFormat();
            DataLine.Info info = new DataLine.Info(Clip.class, format);

            new Thread(() ->
            {
                try {
                    clip = (Clip) AudioSystem.getLine(info);
                    clip.addLineListener(new LineListener() {
                        public void update(LineEvent event) {
                            if (event.getType() == LineEvent.Type.STOP) {
                                if (inform_ended) {
                                    Serial serial = Serial.getInstance();
                                    System.out.println("SENDING F");
                                    serial.sendCharacter('F');
                                    recordBlocked = false;
                                }
                            }
                        }
                    });
                    clip.open(stream);
                    floatControl = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
                    floatControl.setValue(muted ? floatControl.getMinimum() : floatControl.getMaximum());
                    clip.start();
                } catch (IOException | LineUnavailableException e) {
                    controller.displayError("Audio playback failed", "The audio file generated " +
                            "could not be played. Check your code.");
                }
            }).start();
        } catch (IOException | UnsupportedAudioFileException exception) {
            controller.displayError("Audio playback failed", "The audio file generated " +
                    "could not be opened or the format is not supported.");
        }
    }

    private void receiveTower() {
        char sample = ' ';
        List<Character> tower_name = new ArrayList<>();
        Serial serial = Serial.getInstance();

        /* Send ACK */

        serial.sendCharacter('K');

        while ((sample & 0xFF) != '\0') {
            sample = serial.receiveSample();
            if ((sample & 0xFF) != '\0') {
                tower_name.add(sample);
            }
        }

        /* Convert the list of received characters to a string */
        String str_tower = tower_name.stream()
                .map(String::valueOf)
                .collect(Collectors.joining());

        controller.setTowerName(str_tower);
    }

    private void receiveRequestToPlay() {
        char sample = ' ';
        List<Character> index = new ArrayList<>();
        Serial serial = Serial.getInstance();

        /* Send ACK */
        serial.sendCharacter('K');

        while ((sample & 0xFF) != '\0') {
            sample = serial.receiveSample();
            if ((sample & 0xFF) != '\0') {
                index.add(sample);
            }
        }

        /* Convert the list of received characters to a string */
        String str_index = index.stream()
                .map(String::valueOf)
                .collect(Collectors.joining());


        System.out.println("RECEIVED " + str_index);

        /* Find the recording, create the audio file and play it */
        for (Recording recording : recordings) {
            if (recording.getId().equals(str_index)) {
                String path = createAudio(str_index);
                System.out.println("PLAYING " + path);
                if (path != null) {
                    playAudio(path, true);
                } else {
                    System.out.println("ERROR: Audio file not found");
                }
            }
        }
    }

    /*
    When debugging the microphone & the audio playback, be aware that Java's byte datatype is considered signed.
    Therefore, the samples stored in /recordings in .json could be negative due to the way the interpreter represents
    them (CA2). This will have no effect on the audio files generated and their playback.
    */
    /**
     * Defines the communication protocol to exchange all the relevant data about a Recording. Once the communication
     * has ended, a new Recording is instantiated and stored and the list of recordings on program memory is updated.
     */
    private void receiveTrack() {
        /*
        Received samples should be instantiated with the Sample class, beware of the parameters of the constructor
        A recording (with all its attributes) is represented by the Recording class. Notice the parameters that
        are used in the constructor: name, tower, timestamp, id and list of Sample (the class!). The variables that
        are passed to the constructor are already declared, as you can see below, you only need to "fill" them based
        on the data you receive and transmit.
        */

        Recording recording;
        String recordingName;
        // index always contains the index that should be assigned to the recording you are receiving (do not modify)
        // notice that it is a string
        String index = String.valueOf(recordings.size());
        // towerName always contains the name of the tower we are communicating with (do not modify)
        String towerName = controller.getTowerName();
        // timestamp, notice it is a character array (format MM:SS)
        char[] timestamp = new char[Recording.TIMESTAMP_LEN];
        // Recording.MAX_SAMPLES sets the number of samples that will be received (now set to 32768). Use it to fill
        // this list. Notice that the Sample class only has ONE attribute of byte type.
        List<Sample> recordingSamples = new ArrayList<>();

        /*
        Gets the serial instance to use the receiveSample and sendCharacter methods whenever required
        serial.receiveSample() returns the first unprocessed received character
        serial.sendCharacter(char to_send) sends the character to_send over the serial link
         */
        Serial serial = Serial.getInstance();

        // TODO: implement below your own communication protocol to exchange the data of a Recording (PIC <-> Java)
        // <----------------------------------- START OF SOLUTION ----------------------------------->
        System.out.println("Received recording samples");

        char aux = (char) serial.receiveSample();
        timestamp[0] = (char) ((aux/10) + '0'); // Add the ASCII value of '0' to get the corresponding character
        timestamp[1] = (char) ((aux%10) + '0');;
        timestamp[2] = ':';
        aux = (char) serial.receiveSample();
        timestamp[3] = (char) ((aux/10) + '0'); // Add the ASCII value of '0' to get the corresponding character
        timestamp[4] = (char) ((aux%10) + '0');;

        System.out.println("Received recording timestamp");
        System.out.println(timestamp);

        int indexInt = Integer.parseInt(index);
        char toSend = (char) indexInt;

        System.out.println("Sending " + toSend);
        serial.sendCharacter(toSend);

        // Receive recording samples
        for (int j = 0; j < Recording.MAX_SAMPLES; j++) {
            byte sampleData = (byte) serial.receiveSample();
            Sample auxSample = new Sample(sampleData);
            System.out.println("Received sample " + j);
            recordingSamples.add(auxSample);
        }

        // <------------------------------------ END OF SOLUTION ------------------------------------>
        /*
        All your code (to receive a Recording and all its relevant data) should be above. Once the data from the
        PIC has been received (and you transmitted to it what was needed), the following lines will:
            1. Open a dialogue to set the name of the recording (recordingName).
            2. Check if the name of the recording is not null (it is empty).
            3. Call the DAO's saveRecording method, which receives the Recording (containing all the data) as a
            parameter. This method will save the Recording in a new file at /res/recordings in .json format.
            4. Call the controller's updateRecordings method to load the new recording in program memory (so that
            it can be shown in the view, and therefore played).
        After this code snippet runs, if you have received the Recording successfully and instantiated the class as
        required, you should see the received Recording in the view and be able to play it back.
        You DO NOT need to modify any other methods, they are working as is. Only change/add code where there are TODOs.
         */
        recordBlocked = false;
        recordingName = controller.getRecordingName();
        if (recordingName != null) {
            recording = new Recording(recordingName, towerName, new String(timestamp), index, recordingSamples);
            recordingDAO.saveRecording(recording);
            controller.updateRecordings();
        }
    }
}
