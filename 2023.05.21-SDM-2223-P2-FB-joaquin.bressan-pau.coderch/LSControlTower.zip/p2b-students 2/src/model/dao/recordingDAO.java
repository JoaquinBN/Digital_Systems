package model.dao;

import model.entity.Recording;

import java.util.List;

public interface recordingDAO {
    Recording getRecording(String recordingPath);

    List<Recording> getAllRecordings();

    void saveRecording(Recording recording);
}
