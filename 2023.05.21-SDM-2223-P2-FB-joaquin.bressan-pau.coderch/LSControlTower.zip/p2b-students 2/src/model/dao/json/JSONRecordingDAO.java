package model.dao.json;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import model.dao.recordingDAO;
import model.entity.Recording;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class JSONRecordingDAO implements recordingDAO {
    public static final String PATH_AUDIO = "res/audio/";
    public static final String EXT_AUDIO = ".wav";
    private static final String PATH = "res/recordings/";
    private static final String EXT = ".json";

    @Override
    public Recording getRecording(String recordingPath) {
        Gson gson = new Gson();

        Recording recording = null;

        try (FileReader reader = new FileReader(recordingPath)) {
            recording = gson.fromJson(reader, Recording.class);
        } catch (IOException ignored) {
        }

        return recording;
    }

    @Override
    public List<Recording> getAllRecordings() {
        File folder = new File(PATH);
        List<Recording> recordings = new ArrayList<>();

        for (File fileEntry : folder.listFiles()) {
            recordings.add(getRecording(fileEntry.getPath()));
        }

        return recordings;
    }

    @Override
    public void saveRecording(Recording recording) {
        String path = PATH + recording.getName() + EXT;
        Gson gson = new GsonBuilder().setPrettyPrinting().create();

        try (FileWriter writer = new FileWriter(path)) {
            gson.toJson(recording, writer);
        } catch (IOException ignored) {
        }
    }
}
