package controller;

import model.TowerManager;
import view.TowerView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class TowerController implements ActionListener, MouseListener {
    private static final int NUMBER_TIMES_CLICKED = 2;

    private final TowerView towerView;
    private final TowerManager towerManager;

    public TowerController(TowerView towerView, TowerManager towerManager) {
        this.towerView = towerView;
        this.towerManager = towerManager;
        updateRecordings();
    }

    /* -------------------------------------- MODEL-VIEW -------------------------------------- */

    public void displayError(String errorTitle, String errorMessage) {
        towerView.displayError(errorTitle, errorMessage);
    }

    public void startRecording() {
        towerView.setRecording(true);
    }

    public void endRecording() {
        towerView.setRecording(false);
    }

    public String getRecordingName() {
        return towerView.saveRecording();
    }

    public void updateRecordings() {
        towerView.loadModelData(towerManager.getAllRecordings());
    }

    public void setTowerName(String name) {
        towerView.setTowerName(name);
    }

    public String getTowerName() {
        return towerView.getTowerName();
    }

    /* -------------------------------------- VIEW-MODEL -------------------------------------- */

    /* ActionListener */
    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case TowerView.AC_MUTE -> towerView.swapVolumeIcon(towerManager.mute());
            case TowerView.AC_SERIAL -> towerView.updateStatus(towerView.configureSerial());
        }
    }

    /* MouseListener */
    @Override
    public void mousePressed(MouseEvent e) {
        if ((e.getClickCount() == NUMBER_TIMES_CLICKED) && SwingUtilities.isLeftMouseButton(e)) {
            if (towerView.getjTable() == e.getSource()) {
                String path = towerManager.createAudio(towerView.getSelectedID());
                if (path != null) {
                    towerManager.playAudio(path, false);
                }
            }
        }
    }

    /* MouseListener (Ignored) */
    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
}
