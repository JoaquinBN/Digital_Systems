import controller.TowerController;
import model.TowerManager;
import view.TowerView;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() ->
        {
            /* model-view-controller */
            TowerManager towerManager = new TowerManager();
            TowerView towerView = new TowerView();
            TowerController controller = new TowerController(towerView, towerManager);

            /* Setup */
            towerView.registerController(controller);
            towerManager.registerController(controller);

            towerView.setVisible(true);
            towerManager.receiveRequest();
        });
    }
}
